<?php 

require_once 'config.php';

if($_POST) {

	$start_date = $_REQUEST['startdate'];



	$end_date = $_REQUEST['enddate'];





	$sql = "SELECT * FROM orders WHERE placed_on >= '$start_date' AND placed_on <= '$end_date'";
	$query = $conn->query($sql);

	$table = '
	<table border="1" cellspacing="0" cellpadding="0" style="width:100%;">
		<tr>
			<th>Order Date</th>
			<th>Client Name</th>
			<th>Contact</th>
			<th>Grand Total</th>
		</tr>

		<tr>';
		$totalAmount = "";
		while ($result = $query->fetch_assoc()) {
			$table .= '<tr>
				<td><center>'.$result['placed_on'].'</center></td>
				<td><center>'.$result['name'].'</center></td>
				<td><center>'.$result['number'].'</center></td>
				<td><center>'.$result['total_price'].'</center></td>
			</tr>';	
			$totalAmount += $result['total_price'];
		}
		$table .= '
		</tr>

		<tr>
			<td colspan="3"><center>Total Amount</center></td>
			<td><center>'.$totalAmount.'</center></td>
		</tr>
	</table>
	';	

	echo $table;

}

?>