
<?php

include 'config.php';
session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>products</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom admin css file link  -->
   <link rel="stylesheet" href="css/admin_style.css">

</head>
<body>
   
<?php include 'admin_header.php'; ?>

<!-- product CRUD section starts  -->

<section class="add-products">

   

   <form action="getOrderReport.php" method="post" enctype="multipart/form-data">
      <h3>REPORT BASED ON DATE</h3>
      <input type="date" name="startdate" class="box" placeholder="start date" required>
      <input type="date" name="enddate"class="box" placeholder="end date" required>
      <input type="submit" value="Submit"  name="admin_orders.php" class="btn">
   </form>

</section>

<!-- product CRUD section ends -->

<!-- show products  -->


      








<!-- custom admin js file link  -->
<script src="js/admin_script.js"></script>

</body>
</html>